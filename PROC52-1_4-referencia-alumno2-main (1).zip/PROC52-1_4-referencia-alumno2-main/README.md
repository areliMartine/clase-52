# PROC52-1_4-referencia-alumno2
Dispara al zombi III. Etapa 3.  
Actividad del alumno - plantilla.  
  
### Nombre en Inglés: Shoot-the-zoombie-III
Zombie-Shooter-stage-3
